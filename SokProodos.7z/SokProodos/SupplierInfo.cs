﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SokProodos
{
    public partial class SupplierInfo: Form
    {
        private string connectionString = @"Server=SOCHAX\SQLEXPRESS;Database=AdventureWorks2022;Trusted_Connection=True;";
        public SupplierInfo()
        {
            InitializeComponent();
            LoadSuppliers();

            comboBoxSuppliers.SelectedIndexChanged += comboBoxSuppliers_SelectedIndexChanged;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            using (LinearGradientBrush brush = new LinearGradientBrush(
                this.ClientRectangle,
                Color.FromArgb(45, 50, 60),  // Dark Grey
                Color.FromArgb(150, 155, 165), // Lighter Grey
                LinearGradientMode.Vertical))
            {
                e.Graphics.FillRectangle(brush, this.ClientRectangle);
            }
        }

        private void LoadSuppliers()
        {
            comboBoxSuppliers.Items.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"
                        SELECT BusinessEntityID, Name 
                        FROM Purchasing.Vendor 
                        ORDER BY Name ASC;";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            comboBoxSuppliers.Items.Add(new KeyValuePair<int, string>(
                                reader.GetInt32(0), reader.GetString(1)));
                        }
                    }

                    comboBoxSuppliers.DisplayMember = "Value";
                    comboBoxSuppliers.ValueMember = "Key";
                    comboBoxSuppliers.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    comboBoxSuppliers.AutoCompleteSource = AutoCompleteSource.ListItems;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading suppliers: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void LoadSupplierInfo(int supplierId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"
                        SELECT Name, CreditRating, PreferredVendorStatus, ActiveFlag, PurchasingWebServiceURL 
                        FROM Purchasing.Vendor 
                        WHERE BusinessEntityID = @SupplierID;";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SupplierID", supplierId);

                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);

                            // Debugging: Check if data is retrieved
                            MessageBox.Show($"Rows retrieved: {dt.Rows.Count}", "Debug", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Assign data to DataGridView
                            dataGridViewSupplierInfo.DataSource = dt;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading supplier info: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void comboBoxSuppliers_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxSuppliers.SelectedItem != null)
            {
                int supplierId = ((KeyValuePair<int, string>)comboBoxSuppliers.SelectedItem).Key;

                // Debugging: Ensure correct ID is selected
                MessageBox.Show($"Selected Supplier ID: {supplierId}", "Debug", MessageBoxButtons.OK, MessageBoxIcon.Information);

                LoadSupplierInfo(supplierId);
            }
        }
        private void buttonBack_Click(object sender, EventArgs e)
        {
            MainForm mainForm = new MainForm();
            mainForm.Show();
            this.Hide();
        }
    }
}
